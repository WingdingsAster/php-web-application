<?php
class Otdel extends Table {
    public $otdel_id = 0;
    public $name = '';
    public $active = 1;

    public function validate($otdel_id = 0, $name = '', $active = 1) {
        $this->otdel_id = $otdel_id;
        $this->name = $name;
        $this->active = $active;
        return false;
    }

    // public function arrOtdels(){
    
    //     $res = $this->db->query("SELECT otdel_id AS id, name AS value FROM otdel");
    
        
    //     return $res->fetchAll(PDO::FETCH_ASSOC);
    //     }
    

}

?>
