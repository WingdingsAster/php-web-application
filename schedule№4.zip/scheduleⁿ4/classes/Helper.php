<?php

class Helper {
    public static function clearString($str) {
        return trim(strip_tags($str));
    }
    
    public static function clearInt($str) {
        return (int)$str;
    }

    public static function printSelectOptions($key, $options){
    
        if ($options) {
            
            foreach ($options as $option) { ?>
                <option value="<?=$option['id'];?>" <?=($key == $option['id'])?'selected':'';?>>
                    <?=$option['value'];?>
                </option>
            <?php }
        }
    }


    public static function paginator($count, $current = 1, $size = 30) {
        $numPages = ceil($count / $size);
        $href = $_SERVER['PHP_SELF'].'?page=';
        echo '<ul class="pagination">';
        for ($i = 1; $i <= $numPages; $i++) {
            if ($current == $i) {
                echo '<li class="page-item active"><a class="page-link" href="'.$href.$i.'" tabindex="0">'.$i.'</a></li>';
            } else {
                echo '<li class="page-item"><a class="page-link" href="'.$href.$i.'" tabindex="0">'.$i.'</a></li>';
            }
        }
        echo '</ul>';
    }

}
