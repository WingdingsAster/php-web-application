<?php

class User extends Table{
    public $user_id = 0;
    public $lastname = '';
    public $firstname = '';
    public $patronomic = '';
    public $login = '';
    public $pass =  '';
    public $gender_id = 0;
    public $birthday =  '';
    public $role_id = 0;

    public function validate($user_id = 0, $lastname = '', $firstname = '', $patronomic = '', $login = '', $pass = '', $gender_id = 0, $birthday = date(), $role_id = 0) {
        if (!empty($this->lastname) &&
            !empty($this->firstname) &&
            !empty($this->login) &&
            !empty($this->pass) &&
            !empty($this->role_id) &&
            !empty($this->gender_id)) {
            return true;
        }
        return false;
    }
}

?>