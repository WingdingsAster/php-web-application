<!DOCTYPE html>
<html>
<head>
	<title>Страница не найдена</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="container">
		<h1>Страница не найдена</h1>
		<p>К сожалению, запрашиваемая вами страница не найдена.</p>
	</div>
</body>
</html>