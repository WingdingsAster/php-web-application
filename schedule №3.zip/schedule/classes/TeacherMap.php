<?php
class TeacherMap extends BaseMap{

}
?>