<?php
class SpecialMap extends BaseMap{
    
}

?>